package com.example.MyFlower;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;


public class irrigationControl extends AppCompatActivity {
    sqllite_katmani mDataBaseHelper;
    ArrayList<String> selectedItems;
    int i=0;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_irrigation_control);
        mDataBaseHelper = new sqllite_katmani(this);
        selectedItems=new ArrayList<String>();
        Button btn= findViewById(R.id.btshow);
        ListView chl=(ListView) findViewById(R.id.checkable_list);
        chl.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        Cursor data=mDataBaseHelper.getNames();
        ArrayList<String> liste1=new ArrayList<>();
        while(data.moveToNext()){
            liste1.add(data.getString(2));
        }
        ArrayAdapter<String> aa=new ArrayAdapter<String>(this,R.layout.checkable_list_layout,R.id.txt_title,liste1);
        chl.setAdapter(aa);
        chl.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = ((TextView) view).getText().toString();
                Toast.makeText(irrigationControl.this, selectedItem, Toast.LENGTH_SHORT).show();
                CheckedTextView checkedTextView= (CheckedTextView)view;
                if(checkedTextView.isChecked()){
                    selectedItems.add(selectedItem);

                }
                else{
                    selectedItems.remove(selectedItem);
                }
            }
        });
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i++;
                String items="";
                for(String item:selectedItems){
                    items+="-"+item+"\n";
                }
                Toast.makeText(irrigationControl.this,"Watered for the " + i + " time \n"+items,Toast.LENGTH_LONG).show();
            }}); }}