package com.example.MyFlower;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btnadd= findViewById(R.id.btnadd);
        Button btnList= findViewById(R.id.btnlist);
        Button btnsearch = findViewById(R.id.btnsearch);
        Button btnwater = findViewById(R.id.btnwater);
        Button btnlist=findViewById(R.id.btnList);
        Button btnabakim=findViewById(R.id.btnBakim);
        btnadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gonext = new Intent(MainActivity.this, addFlower.class);
                startActivity(gonext);
            }

        });
        btnList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent next2 = new Intent(MainActivity.this, showFlower.class);
                startActivity(next2);
            }
        });
        btnsearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent next3 = new Intent(MainActivity.this, searchPage.class);
                startActivity(next3);
            }
        });
        btnwater.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent next4 = new Intent(MainActivity.this, irrigationControl.class);
                startActivity(next4);
            }
        });
        btnlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent next5 = new Intent(MainActivity.this, Shopping_List.class);
                startActivity(next5);
            }
        });
        btnabakim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent next6 = new Intent(MainActivity.this,Bakim.class);
                startActivity(next6);
            }
        });
    }
}