package com.example.MyFlower;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class searchPage extends AppCompatActivity {
        Button btnsearch;
        TextView tvSearch;
        String word;
        String id,ad,su,kategori,saksi,toprak,aciklama,not;
        byte[] image;

    sqllite_katmani mDataBaseHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_page);
        btnsearch=findViewById(R.id.btnAra);
        tvSearch=findViewById(R.id.etSearch);
        mDataBaseHelper = new sqllite_katmani(this);
        btnsearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            word = tvSearch.getText().toString();
            //word
            Cursor data1 =mDataBaseHelper.Search(word);

                if (data1.getCount()==0){
                    Toast.makeText(getApplicationContext(),"No record Found",Toast.LENGTH_SHORT).show();
                    return;
                }
                while(data1.moveToNext()) {
                    id=data1.getString(0);
                    image= data1.getBlob(1);
                    ad=data1.getString(2);
                    kategori=data1.getString(3);
                    su=data1.getString(4);
                    saksi=data1.getString(5);
                    toprak=data1.getString(6);
                    aciklama=data1.getString(7);
                    not=data1.getString(8);
                }
                Intent i = new Intent(searchPage.this, flowerPage.class);
                i.putExtra("id",id);
                i.putExtra("image",image);
                i.putExtra("ad",ad);
                i.putExtra("kategori",kategori);
                i.putExtra("su",su);
                i.putExtra("saksi",saksi);
                i.putExtra("toprak",toprak);
                i.putExtra("aciklama",aciklama);
                i.putExtra("not",not);
                startActivity(i);
            }}); }}