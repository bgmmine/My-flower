package com.example.MyFlower;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
public class sqllite_katmani extends SQLiteOpenHelper {
    public static final String  DB_AD = "flowers";
    public static final String  DB = "flower.db";
    public static final String  ROW_ID = "flowerID";
    public static final String ROW_RESIM ="image";
    public static final String ROW_AD="name";
    public static final String ROW_CATEGORY="category";
    public static final String ROW_WATER="water";
    public static final String ROW_POT="pot";
    public static final String ROW_SOIL="soil";
    public static final String ROW_EXP="explanation";
    public static final String ROW_NOTS="nots";
    ContentResolver mContentResolver;
    public sqllite_katmani(Context c) {
        super(c,DB , null, 1);
        mContentResolver = c.getContentResolver();
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE "+DB_AD+"("
                +ROW_ID+" INTEGER PRIMARY KEY AUTOINCREMENT,"
                +ROW_RESIM+" BLOB,"
                +ROW_AD+" TEXT NOT NULL,"
                +ROW_CATEGORY+" TEXT NOT NULL, "
                +ROW_WATER+" TEXT,"
                +ROW_POT+" TEXT, "
                +ROW_SOIL+" TEXT, "
                +ROW_EXP+" TEXT,"
                + ROW_NOTS+" TEXT)");
        String sql2 = "create table  alisverislistesi ( malzemeId integer primary key not null , malzeme_adi text not null)";
        db.execSQL(sql2);
        String sql3 = "insert into alisverislistesi (malzeme_adi) values  ('Irrigation Equipment'), ('Pesticides'), ('Pot'), ('Plant Stands'), ('Pruning Tools'), ('Seeds'), ('Soil'), ('Vitamins') " ;
        db.execSQL(sql3);
        String sql4 = "create table  bakim ( bakimId integer primary key not null , bakim_adi text not null)";
        db.execSQL(sql4);
        String sql5 = "insert into bakim (bakim_adi) values  ('Cleaning'), ('Fertilization'), ('Hoeing'), ('Pruning'), ('Soil aeration'), ('Vitamin care') " ;
        db.execSQL(sql5);
    }
@Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP  TABLE tariflerim ");
        onCreate(db);
    }
    public Cursor getMalzeme() {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM alisverislistesi";
        Cursor data = db.rawQuery(query, null);
        return data;
    }
    public Cursor getBakim() {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM bakim";
        Cursor data = db.rawQuery(query, null);
        return data;
    }
    public void addFlower( byte []image,String name, String category,  String water, String pot, String soil, String exp, String not) {
        SQLiteDatabase db = this.getWritableDatabase();
        try {
            ContentValues cv = new ContentValues();
            cv.put(ROW_RESIM,image);
            cv.put(ROW_AD, name);
            cv.put(ROW_CATEGORY, category);
            cv.put(ROW_WATER, water);
            cv.put(ROW_POT, pot);
            cv.put(ROW_SOIL, soil);
            cv.put(ROW_EXP, exp);
            cv.put(ROW_NOTS, not);
            db.insert(DB_AD, null, cv);
        } catch(Exception e){
        }
        db.close();;
    }
    public void change(String name, String category,  String water, String pot, String soil, String exp, String not,String isim) {
        SQLiteDatabase db = this.getWritableDatabase();
        try {
            ContentValues cv = new ContentValues();
            cv.put(ROW_AD, name);
            cv.put(ROW_CATEGORY, category);
            cv.put(ROW_WATER, water);
            cv.put(ROW_POT, pot);
            cv.put(ROW_SOIL, soil);
            cv.put(ROW_EXP, exp);
            cv.put(ROW_NOTS, not);
            String where = ROW_AD + " = '" + isim + "'";
            db.update(DB_AD, cv, where, null);
        } catch (Exception e) {
        }
    }
    public void Delete(String name){
        SQLiteDatabase db = this.getWritableDatabase();
        try {
            String where = ROW_AD + " = '" + name + "'"  ;
            db.delete(DB_AD,where,null);
        }catch (Exception e){

        }
        db.close();
    }
    public Cursor Search(String name){
        SQLiteDatabase db = this.getWritableDatabase();
        String arama3 = "SELECT * FROM flowers WHERE name = '"+ name +"'";
        Cursor data1 = db.rawQuery(arama3, null);
        return data1 ;
    }
    public Cursor getNames(){
        SQLiteDatabase db= this.getWritableDatabase();
        String query = "SELECT * FROM flowers";
        Cursor data = db.rawQuery(query, null);
        return data;
    }
}
