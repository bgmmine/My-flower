package com.example.MyFlower;
import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
public class Bakim extends Activity {
    sqllite_katmani mDataBaseHelper;
    ArrayList<String> selectedItems;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bakim);
        mDataBaseHelper = new sqllite_katmani(this);
        selectedItems=new ArrayList<String>();
        Button btn= findViewById(R.id.btshow);
        ListView chl=(ListView) findViewById(R.id.checkable_list);
        chl.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        Cursor data=mDataBaseHelper.getBakim();
        ArrayList<String> liste=new ArrayList<>();
        while(data.moveToNext()){
            liste.add(data.getString(1));
        }
        ArrayAdapter<String> aa=new ArrayAdapter<String>(this,R.layout.checkable_list_layout,R.id.txt_title,liste);
        chl.setAdapter(aa);
        chl.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = ((TextView) view).getText().toString();
                CheckedTextView checkedTextView= (CheckedTextView)view;
                if(checkedTextView.isChecked()){
                    selectedItems.add(selectedItem);
                }
                else{
                    selectedItems.remove(selectedItem); } }});
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int i = selectedItems.size();
                int b=6-i;
                String items="";
                for(String item:selectedItems){
                    items+="-"+item+"\n";
                }
                Toast.makeText(Bakim.this,"You have completed "+ i + "in weekly maintenance,"+ b +"  left! Completed:  \n"+items,Toast.LENGTH_LONG).show();
            }}); }}
