package com.example.MyFlower;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

public class ImagesAdapter extends RecyclerView.Adapter<ImagesAdapter.ImagesViewHolder> {
    private String deneme ="Flower";
    private Cursor mCursor;
    private Context mContext;
    String category ;
    String water;
    String pot;
    String soil ;
    String exp ;
    String not ,id;
    byte[] images;
    public ImagesAdapter(Context mContext) {
        this.mContext = mContext;
    }
    @Override
    public ImagesViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mContext);
      View view = inflater.inflate(R.layout.image_item, parent, false);

        return new ImagesViewHolder(view);
    }
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onBindViewHolder(ImagesViewHolder holder, int position) {
        int fragranceName = mCursor.getColumnIndex(sqllite_katmani.ROW_RESIM);
        int idIndex =  mCursor.getColumnIndex(sqllite_katmani.ROW_ID);
        int isimIndex= mCursor.getColumnIndex(sqllite_katmani.ROW_AD);
        int kategoriIndex = mCursor.getColumnIndex(sqllite_katmani.ROW_CATEGORY);
        int waterIndex = mCursor.getColumnIndex(sqllite_katmani.ROW_WATER);
        int potIndex = mCursor.getColumnIndex(sqllite_katmani.ROW_POT);
        int soilIndex = mCursor.getColumnIndex(sqllite_katmani.ROW_SOIL);
        int expIndex = mCursor.getColumnIndex(sqllite_katmani.ROW_EXP);
        int notIndex = mCursor.getColumnIndex(sqllite_katmani.ROW_NOTS);
        mCursor.moveToPosition(position);
         images = mCursor.getBlob(fragranceName);
         id=mCursor.getString(idIndex);
         String isim= mCursor.getString(isimIndex);
        category = mCursor.getString(kategoriIndex);
        water= mCursor.getString(waterIndex);
        pot= mCursor.getString(potIndex);
        soil= mCursor.getString(soilIndex);
        exp = mCursor.getString(expIndex);
        not = mCursor.getString(notIndex);
        Bitmap bmp = BitmapFactory.decodeByteArray(images, 0, images.length);
        holder.image.setImageBitmap(Bitmap.createScaledBitmap(bmp, 200,
                200, false));
        holder.textad.setText(isim);
    }
    @Override
    public int getItemCount() {
        if (mCursor == null) {
            return 0;
        }
        return mCursor.getCount();
    }
    public Cursor swapCursor(Cursor c) {
        if (mCursor == c) {
            return null;
        }
        Cursor temp = mCursor;
        this.mCursor = c;
        if (c != null) {
            this.notifyDataSetChanged();
        }
        return temp;
    }
    public class ImagesViewHolder extends RecyclerView.ViewHolder {
        ImageView image;
        TextView textad;
        public ImagesViewHolder(View itemView) {
            super(itemView);
            image = (ImageView) itemView.findViewById(R.id.imageProf);
            textad= itemView.findViewById(R.id.twad);
            image.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String ad=textad.getText().toString();
                    Intent i=new Intent(mContext,flowerPage.class);
                    i.putExtra("id",id);
                   // i.putExtra("image",images);
                    i.putExtra("ad",ad);
                 /*   i.putExtra("kategori",category);
                    i.putExtra("su",water);
                    i.putExtra("saksi",pot);
                    i.putExtra("toprak",soil);
                    i.putExtra("aciklama",exp);
                    i.putExtra("not",not);*/
                    mContext.startActivity(i);
                }}); }}}