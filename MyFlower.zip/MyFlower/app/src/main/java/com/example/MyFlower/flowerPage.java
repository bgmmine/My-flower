package com.example.MyFlower;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;

public class flowerPage extends AppCompatActivity {
    sqllite_katmani mDataBaseHelper;
    TextView  etCategory,etad,etsu,etpot,etexp,ettoprak,etNot;
    Button btndegisiklik,btnSil;
    ImageView profileImageView;
    String add;
    String idd,ad,su,kategori,toprak,aciklama,saksi,not;
    byte[] image;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flower_page);
        Bundle extras = getIntent().getExtras();
        String id = extras.getString("id");
         add = extras.getString("ad");
        mDataBaseHelper = new sqllite_katmani(this);
        etad = findViewById(R.id.etname);
        etsu = findViewById(R.id.etWater);
        profileImageView = findViewById(R.id.profileImageView);
        etCategory = findViewById(R.id.etCategory);
        etpot = findViewById(R.id.etPot);
        etexp = findViewById(R.id.etexp);
        ettoprak = findViewById(R.id.etSoil);
        etNot = findViewById(R.id.etmNotlar);
        btndegisiklik = findViewById(R.id.btnDegisiklik);
        btnSil = findViewById(R.id.btnSİlme);
        System.out.println("**"+add);
        Cursor data1 =mDataBaseHelper.Search(add);
        if (data1.getCount()==0){
            Toast.makeText(getApplicationContext(),"Kayıt bulunamadı",Toast.LENGTH_SHORT).show();
            return;
        }
        while(data1.moveToNext()) {
            idd=data1.getString(0);
            image= data1.getBlob(1);
            ad=data1.getString(2);
            kategori=data1.getString(3);
            su=data1.getString(4);
            saksi=data1.getString(5);
            toprak=data1.getString(6);
            aciklama=data1.getString(7);
            not=data1.getString(8);
        }
        Bitmap bmp = BitmapFactory.decodeByteArray(image, 0, image.length);
        profileImageView.setImageBitmap(Bitmap.createScaledBitmap(bmp, 200,
                200, false));
        etad.setText(ad);
        etCategory.setText(kategori);
        etsu.setText(su);
        etpot.setText(saksi);
        ettoprak.setText(toprak);
        etexp.setText(aciklama);
        etNot.setText(not);

        btndegisiklik.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                profileImageView.setDrawingCacheEnabled(true);
                profileImageView.buildDrawingCache();
                Bitmap bitmap = profileImageView.getDrawingCache();
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] resim = baos.toByteArray();
                String isim=etad.getText().toString();

                String categori = etCategory.getText().toString();
                String water = etsu.getText().toString();
                String pot = etpot.getText().toString();
                String soil = ettoprak.getText().toString();
                String expl = etexp.getText().toString();
                String nots = etNot.getText().toString();
                sqllite_katmani vt = new sqllite_katmani(flowerPage.this);
                vt.change(ad,categori,water,pot,soil,expl,nots,isim);
                Toast.makeText(flowerPage.this,"Saved successfully ",Toast.LENGTH_SHORT).show();
                Intent gecisYap1 = new Intent(flowerPage.this, showFlower.class);
                startActivity(gecisYap1);
            }
        });
        btnSil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sqllite_katmani vt = new sqllite_katmani(flowerPage.this);
                String ad1=etad.getText().toString();
                Toast.makeText(flowerPage.this, "****"+ad1, Toast.LENGTH_SHORT).show();
                vt.Delete(ad1);
                Intent gecisYap1 = new Intent(flowerPage.this, showFlower.class);
                startActivity(gecisYap1);
            }}); }}